CKEDITOR.editorConfig = function (config) {
   
    config.language = 'fa';
    config.filebrowserImageUploadUrl = '/Upload/Article';
    config.preset = 'full';

};